-- AlterTable
ALTER TABLE `completed_process_data` ADD COLUMN `contactEmail` VARCHAR(191) NULL,
    ADD COLUMN `contactName` VARCHAR(191) NULL,
    ADD COLUMN `publisherId` VARCHAR(191) NULL,
    ADD COLUMN `publisherMatched` BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE `data_final` ADD COLUMN `contactEmail` VARCHAR(191) NULL,
    ADD COLUMN `contactName` VARCHAR(191) NULL,
    ADD COLUMN `publisherId` VARCHAR(191) NULL,
    ADD COLUMN `publisherMatched` BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE `data_in_process` ADD COLUMN `contactEmail` VARCHAR(191) NULL,
    ADD COLUMN `contactName` VARCHAR(191) NULL,
    ADD COLUMN `publisherId` VARCHAR(191) NULL,
    ADD COLUMN `publisherMatched` BOOLEAN NOT NULL DEFAULT false;
