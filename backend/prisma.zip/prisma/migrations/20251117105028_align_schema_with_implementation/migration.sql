/*
  Warnings:

  - You are about to drop the column `da` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `dr` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `gbBasePrice` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `liBasePrice` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `negotiationStatus` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `pushedAt` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `pushedBy` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `siteUrl` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `ss` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `traffic` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `da` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `dr` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `gbBasePrice` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `liBasePrice` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `negotiationStatus` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `reachedAt` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `reachedBy` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `siteUrl` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `ss` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `traffic` on the `data_final` table. All the data in the column will be lost.
  - You are about to drop the column `da` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `dr` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `reachedAt` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `reachedBy` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `siteUrl` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `ss` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `taskId` on the `data_in_process` table. All the data in the column will be lost.
  - You are about to drop the column `traffic` on the `data_in_process` table. All the data in the column will be lost.
  - The values [REACHED,NOT_REACHED,NO_ACTION] on the enum `data_in_process_status` will be removed. If these variants are still used in the database, this will fail.
  - You are about to drop the column `assignedToId` on the `data_upload_tasks` table. All the data in the column will be lost.
  - You are about to drop the column `filename` on the `data_upload_tasks` table. All the data in the column will be lost.
  - You are about to drop the column `newDomains` on the `data_upload_tasks` table. All the data in the column will be lost.
  - You are about to drop the column `skippedDomains` on the `data_upload_tasks` table. All the data in the column will be lost.
  - You are about to drop the column `totalDomains` on the `data_upload_tasks` table. All the data in the column will be lost.
  - You are about to drop the column `uploadedById` on the `data_upload_tasks` table. All the data in the column will be lost.
  - Added the required column `updatedAt` to the `completed_process_data` table without a default value. This is not possible if the table is not empty.
  - Added the required column `websiteUrl` to the `completed_process_data` table without a default value. This is not possible if the table is not empty.
  - Added the required column `websiteUrl` to the `data_final` table without a default value. This is not possible if the table is not empty.
  - Added the required column `uploadTaskId` to the `data_in_process` table without a default value. This is not possible if the table is not empty.
  - Added the required column `websiteUrl` to the `data_in_process` table without a default value. This is not possible if the table is not empty.
  - Added the required column `createdBy` to the `data_upload_tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `fileName` to the `data_upload_tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `invalidRecords` to the `data_upload_tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `totalRecords` to the `data_upload_tasks` table without a default value. This is not possible if the table is not empty.
  - Added the required column `validRecords` to the `data_upload_tasks` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE `completed_process_data` DROP FOREIGN KEY `completed_process_data_pushedBy_fkey`;

-- DropForeignKey
ALTER TABLE `data_final` DROP FOREIGN KEY `data_final_reachedBy_fkey`;

-- DropForeignKey
ALTER TABLE `data_in_process` DROP FOREIGN KEY `data_in_process_reachedBy_fkey`;

-- DropForeignKey
ALTER TABLE `data_in_process` DROP FOREIGN KEY `data_in_process_taskId_fkey`;

-- DropForeignKey
ALTER TABLE `data_upload_tasks` DROP FOREIGN KEY `data_upload_tasks_assignedToId_fkey`;

-- DropForeignKey
ALTER TABLE `data_upload_tasks` DROP FOREIGN KEY `data_upload_tasks_uploadedById_fkey`;

-- DropIndex
DROP INDEX `completed_process_data_pushedAt_idx` ON `completed_process_data`;

-- DropIndex
DROP INDEX `data_final_negotiationStatus_idx` ON `data_final`;

-- DropIndex
DROP INDEX `data_final_status_idx` ON `data_final`;

-- AlterTable
ALTER TABLE `completed_process_data` DROP COLUMN `da`,
    DROP COLUMN `dr`,
    DROP COLUMN `gbBasePrice`,
    DROP COLUMN `liBasePrice`,
    DROP COLUMN `negotiationStatus`,
    DROP COLUMN `pushedAt`,
    DROP COLUMN `pushedBy`,
    DROP COLUMN `siteUrl`,
    DROP COLUMN `ss`,
    DROP COLUMN `status`,
    DROP COLUMN `traffic`,
    ADD COLUMN `completedAt` DATETIME(3) NULL,
    ADD COLUMN `completedBy` VARCHAR(191) NULL,
    ADD COLUMN `daRange` VARCHAR(191) NULL,
    ADD COLUMN `linkType` VARCHAR(191) NULL,
    ADD COLUMN `notes` VARCHAR(191) NULL,
    ADD COLUMN `price` DOUBLE NULL,
    ADD COLUMN `publisherContact` VARCHAR(191) NULL,
    ADD COLUMN `publisherEmail` VARCHAR(191) NULL,
    ADD COLUMN `updatedAt` DATETIME(3) NOT NULL,
    ADD COLUMN `websiteUrl` VARCHAR(191) NOT NULL,
    MODIFY `publisherName` VARCHAR(191) NULL,
    MODIFY `category` VARCHAR(191) NULL,
    MODIFY `country` VARCHAR(191) NULL,
    MODIFY `language` VARCHAR(191) NULL,
    MODIFY `tat` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `data_final` DROP COLUMN `da`,
    DROP COLUMN `dr`,
    DROP COLUMN `gbBasePrice`,
    DROP COLUMN `liBasePrice`,
    DROP COLUMN `negotiationStatus`,
    DROP COLUMN `reachedAt`,
    DROP COLUMN `reachedBy`,
    DROP COLUMN `siteUrl`,
    DROP COLUMN `ss`,
    DROP COLUMN `status`,
    DROP COLUMN `traffic`,
    ADD COLUMN `daRange` VARCHAR(191) NULL,
    ADD COLUMN `linkType` VARCHAR(191) NULL,
    ADD COLUMN `mainProjectId` VARCHAR(191) NULL,
    ADD COLUMN `notes` VARCHAR(191) NULL,
    ADD COLUMN `price` DOUBLE NULL,
    ADD COLUMN `publisherContact` VARCHAR(191) NULL,
    ADD COLUMN `pushedAt` DATETIME(3) NULL,
    ADD COLUMN `pushedBy` VARCHAR(191) NULL,
    ADD COLUMN `websiteUrl` VARCHAR(191) NOT NULL,
    MODIFY `publisherName` VARCHAR(191) NULL,
    MODIFY `category` VARCHAR(191) NULL,
    MODIFY `country` VARCHAR(191) NULL,
    MODIFY `language` VARCHAR(191) NULL,
    MODIFY `tat` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `data_in_process` DROP COLUMN `da`,
    DROP COLUMN `dr`,
    DROP COLUMN `reachedAt`,
    DROP COLUMN `reachedBy`,
    DROP COLUMN `siteUrl`,
    DROP COLUMN `ss`,
    DROP COLUMN `taskId`,
    DROP COLUMN `traffic`,
    ADD COLUMN `daRange` VARCHAR(191) NULL,
    ADD COLUMN `linkType` VARCHAR(191) NULL,
    ADD COLUMN `notes` VARCHAR(191) NULL,
    ADD COLUMN `price` DOUBLE NULL,
    ADD COLUMN `publisherContact` VARCHAR(191) NULL,
    ADD COLUMN `uploadTaskId` VARCHAR(191) NOT NULL,
    ADD COLUMN `websiteUrl` VARCHAR(191) NOT NULL,
    MODIFY `category` VARCHAR(191) NULL,
    MODIFY `country` VARCHAR(191) NULL,
    MODIFY `language` VARCHAR(191) NULL,
    MODIFY `tat` VARCHAR(191) NULL,
    MODIFY `status` ENUM('PENDING', 'VERIFIED', 'REJECTED', 'PUSHED') NOT NULL DEFAULT 'PENDING';

-- AlterTable
ALTER TABLE `data_upload_tasks` DROP COLUMN `assignedToId`,
    DROP COLUMN `filename`,
    DROP COLUMN `newDomains`,
    DROP COLUMN `skippedDomains`,
    DROP COLUMN `totalDomains`,
    DROP COLUMN `uploadedById`,
    ADD COLUMN `assignedTo` VARCHAR(191) NULL,
    ADD COLUMN `createdBy` VARCHAR(191) NOT NULL,
    ADD COLUMN `duplicateRecords` INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN `fileName` VARCHAR(191) NOT NULL,
    ADD COLUMN `invalidRecords` INTEGER NOT NULL,
    ADD COLUMN `notes` VARCHAR(191) NULL,
    ADD COLUMN `processedRecords` INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN `pushedRecords` INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN `totalRecords` INTEGER NOT NULL,
    ADD COLUMN `uploadedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    ADD COLUMN `validRecords` INTEGER NOT NULL;

-- CreateIndex
CREATE INDEX `completed_process_data_mainProjectId_idx` ON `completed_process_data`(`mainProjectId`);

-- CreateIndex
CREATE INDEX `completed_process_data_completedBy_idx` ON `completed_process_data`(`completedBy`);

-- CreateIndex
CREATE INDEX `completed_process_data_websiteUrl_idx` ON `completed_process_data`(`websiteUrl`);

-- CreateIndex
CREATE INDEX `data_final_mainProjectId_idx` ON `data_final`(`mainProjectId`);

-- CreateIndex
CREATE INDEX `data_final_pushedBy_idx` ON `data_final`(`pushedBy`);

-- CreateIndex
CREATE INDEX `data_final_websiteUrl_idx` ON `data_final`(`websiteUrl`);

-- CreateIndex
CREATE INDEX `data_in_process_uploadTaskId_idx` ON `data_in_process`(`uploadTaskId`);

-- CreateIndex
CREATE INDEX `data_in_process_websiteUrl_idx` ON `data_in_process`(`websiteUrl`);

-- CreateIndex
CREATE INDEX `data_upload_tasks_assignedTo_idx` ON `data_upload_tasks`(`assignedTo`);

-- CreateIndex
CREATE INDEX `data_upload_tasks_createdBy_idx` ON `data_upload_tasks`(`createdBy`);

-- CreateIndex
CREATE INDEX `data_upload_tasks_status_idx` ON `data_upload_tasks`(`status`);

-- AddForeignKey
ALTER TABLE `data_upload_tasks` ADD CONSTRAINT `data_upload_tasks_assignedTo_fkey` FOREIGN KEY (`assignedTo`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_upload_tasks` ADD CONSTRAINT `data_upload_tasks_createdBy_fkey` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_in_process` ADD CONSTRAINT `data_in_process_uploadTaskId_fkey` FOREIGN KEY (`uploadTaskId`) REFERENCES `data_upload_tasks`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_final` ADD CONSTRAINT `data_final_pushedBy_fkey` FOREIGN KEY (`pushedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `completed_process_data` ADD CONSTRAINT `completed_process_data_completedBy_fkey` FOREIGN KEY (`completedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
