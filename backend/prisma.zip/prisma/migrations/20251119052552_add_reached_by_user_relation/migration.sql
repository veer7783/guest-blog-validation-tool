-- CreateIndex
CREATE INDEX `data_final_reachedBy_idx` ON `data_final`(`reachedBy`);

-- AddForeignKey
ALTER TABLE `data_final` ADD CONSTRAINT `data_final_reachedBy_fkey` FOREIGN KEY (`reachedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
