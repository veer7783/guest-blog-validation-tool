-- AlterTable
ALTER TABLE `data_final` ADD COLUMN `lastModifiedBy` VARCHAR(191) NULL,
    ADD COLUMN `lastModifiedByName` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `data_in_process` ADD COLUMN `lastModifiedBy` VARCHAR(191) NULL,
    ADD COLUMN `lastModifiedByName` VARCHAR(191) NULL;
