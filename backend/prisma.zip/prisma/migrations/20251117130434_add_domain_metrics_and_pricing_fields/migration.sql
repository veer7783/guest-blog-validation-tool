/*
  Warnings:

  - You are about to drop the column `price` on the `completed_process_data` table. All the data in the column will be lost.
  - You are about to drop the column `price` on the `data_final` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `completed_process_data` DROP COLUMN `price`,
    ADD COLUMN `da` INTEGER NULL,
    ADD COLUMN `dr` INTEGER NULL,
    ADD COLUMN `gbBasePrice` DOUBLE NULL,
    ADD COLUMN `liBasePrice` DOUBLE NULL,
    ADD COLUMN `negotiationStatus` VARCHAR(191) NULL,
    ADD COLUMN `ss` INTEGER NULL,
    ADD COLUMN `status` VARCHAR(191) NULL,
    ADD COLUMN `traffic` INTEGER NULL;

-- AlterTable
ALTER TABLE `data_final` DROP COLUMN `price`,
    ADD COLUMN `da` INTEGER NULL,
    ADD COLUMN `dr` INTEGER NULL,
    ADD COLUMN `gbBasePrice` DOUBLE NULL,
    ADD COLUMN `liBasePrice` DOUBLE NULL,
    ADD COLUMN `negotiationStatus` ENUM('IN_PROGRESS', 'DONE') NOT NULL DEFAULT 'IN_PROGRESS',
    ADD COLUMN `reachedAt` DATETIME(3) NULL,
    ADD COLUMN `reachedBy` VARCHAR(191) NULL,
    ADD COLUMN `ss` INTEGER NULL,
    ADD COLUMN `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    ADD COLUMN `traffic` INTEGER NULL;

-- AlterTable
ALTER TABLE `data_in_process` ADD COLUMN `da` INTEGER NULL,
    ADD COLUMN `dr` INTEGER NULL,
    ADD COLUMN `reachedAt` DATETIME(3) NULL,
    ADD COLUMN `reachedBy` VARCHAR(191) NULL,
    ADD COLUMN `ss` INTEGER NULL,
    ADD COLUMN `traffic` INTEGER NULL,
    MODIFY `status` ENUM('PENDING', 'REACHED', 'NOT_REACHED', 'NO_ACTION', 'VERIFIED', 'REJECTED', 'PUSHED') NOT NULL DEFAULT 'PENDING';

-- AlterTable
ALTER TABLE `data_upload_tasks` MODIFY `status` ENUM('PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED') NOT NULL DEFAULT 'PENDING';

-- CreateIndex
CREATE INDEX `data_final_status_idx` ON `data_final`(`status`);

-- CreateIndex
CREATE INDEX `data_final_negotiationStatus_idx` ON `data_final`(`negotiationStatus`);
