-- AlterTable
ALTER TABLE `data_in_process` ADD COLUMN `gbBasePrice` DOUBLE NULL,
    ADD COLUMN `liBasePrice` DOUBLE NULL;
