-- CreateTable
CREATE TABLE `users` (
    `id` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `password` VARCHAR(191) NOT NULL,
    `firstName` VARCHAR(191) NOT NULL,
    `lastName` VARCHAR(191) NOT NULL,
    `role` ENUM('ADMIN', 'SUPER_ADMIN') NOT NULL DEFAULT 'ADMIN',
    `isActive` BOOLEAN NOT NULL DEFAULT true,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `users_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `two_factor_auth` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `secret` VARCHAR(191) NOT NULL,
    `backupCodes` JSON NOT NULL,
    `isEnabled` BOOLEAN NOT NULL DEFAULT false,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `two_factor_auth_userId_key`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `data_upload_tasks` (
    `id` VARCHAR(191) NOT NULL,
    `filename` VARCHAR(191) NOT NULL,
    `totalDomains` INTEGER NOT NULL,
    `newDomains` INTEGER NOT NULL,
    `skippedDomains` INTEGER NOT NULL,
    `assignedToId` VARCHAR(191) NULL,
    `uploadedById` VARCHAR(191) NOT NULL,
    `status` ENUM('PENDING', 'IN_PROGRESS', 'COMPLETED') NOT NULL DEFAULT 'PENDING',
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `data_in_process` (
    `id` VARCHAR(191) NOT NULL,
    `taskId` VARCHAR(191) NOT NULL,
    `siteUrl` VARCHAR(191) NOT NULL,
    `publisherEmail` VARCHAR(191) NULL,
    `publisherName` VARCHAR(191) NULL,
    `da` INTEGER NULL,
    `dr` INTEGER NULL,
    `traffic` INTEGER NULL,
    `ss` INTEGER NULL,
    `category` VARCHAR(191) NOT NULL,
    `country` VARCHAR(191) NOT NULL,
    `language` VARCHAR(191) NOT NULL DEFAULT 'en',
    `tat` VARCHAR(191) NOT NULL,
    `status` ENUM('PENDING', 'REACHED', 'NOT_REACHED', 'NO_ACTION') NOT NULL DEFAULT 'PENDING',
    `reachedBy` VARCHAR(191) NULL,
    `reachedAt` DATETIME(3) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    INDEX `data_in_process_taskId_idx`(`taskId`),
    INDEX `data_in_process_status_idx`(`status`),
    INDEX `data_in_process_reachedBy_idx`(`reachedBy`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `data_final` (
    `id` VARCHAR(191) NOT NULL,
    `siteUrl` VARCHAR(191) NOT NULL,
    `publisherName` VARCHAR(191) NOT NULL,
    `publisherEmail` VARCHAR(191) NULL,
    `da` INTEGER NULL,
    `dr` INTEGER NULL,
    `traffic` INTEGER NULL,
    `ss` INTEGER NULL,
    `category` VARCHAR(191) NOT NULL,
    `country` VARCHAR(191) NOT NULL,
    `language` VARCHAR(191) NOT NULL DEFAULT 'en',
    `tat` VARCHAR(191) NOT NULL,
    `gbBasePrice` DOUBLE NOT NULL,
    `liBasePrice` DOUBLE NULL,
    `status` ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    `negotiationStatus` ENUM('IN_PROGRESS', 'DONE') NOT NULL DEFAULT 'IN_PROGRESS',
    `reachedBy` VARCHAR(191) NOT NULL,
    `reachedAt` DATETIME(3) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    INDEX `data_final_reachedBy_idx`(`reachedBy`),
    INDEX `data_final_status_idx`(`status`),
    INDEX `data_final_negotiationStatus_idx`(`negotiationStatus`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `completed_process_data` (
    `id` VARCHAR(191) NOT NULL,
    `siteUrl` VARCHAR(191) NOT NULL,
    `publisherName` VARCHAR(191) NOT NULL,
    `da` INTEGER NULL,
    `dr` INTEGER NULL,
    `traffic` INTEGER NULL,
    `ss` INTEGER NULL,
    `category` VARCHAR(191) NOT NULL,
    `country` VARCHAR(191) NOT NULL,
    `language` VARCHAR(191) NOT NULL,
    `tat` VARCHAR(191) NOT NULL,
    `gbBasePrice` DOUBLE NOT NULL,
    `liBasePrice` DOUBLE NULL,
    `status` VARCHAR(191) NOT NULL,
    `negotiationStatus` VARCHAR(191) NOT NULL,
    `pushedBy` VARCHAR(191) NOT NULL,
    `pushedAt` DATETIME(3) NOT NULL,
    `mainProjectId` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `completed_process_data_pushedBy_idx`(`pushedBy`),
    INDEX `completed_process_data_pushedAt_idx`(`pushedAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `activity_logs` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `action` VARCHAR(191) NOT NULL,
    `entityType` VARCHAR(191) NOT NULL,
    `entityId` VARCHAR(191) NULL,
    `details` JSON NULL,
    `ipAddress` VARCHAR(191) NULL,
    `userAgent` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `activity_logs_userId_idx`(`userId`),
    INDEX `activity_logs_action_idx`(`action`),
    INDEX `activity_logs_entityType_idx`(`entityType`),
    INDEX `activity_logs_createdAt_idx`(`createdAt`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `two_factor_auth` ADD CONSTRAINT `two_factor_auth_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_upload_tasks` ADD CONSTRAINT `data_upload_tasks_assignedToId_fkey` FOREIGN KEY (`assignedToId`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_upload_tasks` ADD CONSTRAINT `data_upload_tasks_uploadedById_fkey` FOREIGN KEY (`uploadedById`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_in_process` ADD CONSTRAINT `data_in_process_taskId_fkey` FOREIGN KEY (`taskId`) REFERENCES `data_upload_tasks`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_in_process` ADD CONSTRAINT `data_in_process_reachedBy_fkey` FOREIGN KEY (`reachedBy`) REFERENCES `users`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `data_final` ADD CONSTRAINT `data_final_reachedBy_fkey` FOREIGN KEY (`reachedBy`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `completed_process_data` ADD CONSTRAINT `completed_process_data_pushedBy_fkey` FOREIGN KEY (`pushedBy`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `activity_logs` ADD CONSTRAINT `activity_logs_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
