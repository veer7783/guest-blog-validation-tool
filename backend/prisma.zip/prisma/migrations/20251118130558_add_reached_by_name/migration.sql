-- AlterTable
ALTER TABLE `data_final` ADD COLUMN `reachedByName` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `data_in_process` ADD COLUMN `reachedByName` VARCHAR(191) NULL;
